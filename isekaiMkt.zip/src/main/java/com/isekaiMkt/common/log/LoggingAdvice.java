package com.isekaiMkt.common.log;

import java.util.Arrays;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class LoggingAdvice {
	private static final Logger logger = LoggerFactory.getLogger(LoggingAdvice.class);

	// target 占쌨쇽옙占쏙옙占쏙옙 占식띰옙占쏙옙孤占� 占쏙옙占쏙옙占쏙옙 占쏙옙占쏙옙爛求占�.
	@Before("execution(* com.isekaiMkt.*.service.*.*(..)) or "
			+ "execution(* com.isekaiMkt.*.dao.*.*(..))")
	public void startLog(JoinPoint jp) {

		logger.info("-------------------------------------");
		logger.info("-------------------------------------");

		// 占쏙옙占쌨되댐옙 占쏙옙占� 占식띰옙占쏙옙孤占쏙옙占� Object占쏙옙 占썼열占쏙옙 占쏙옙占쏙옙占심니댐옙. 
		logger.info("1:" + Arrays.toString(jp.getArgs()));

		//占쌔댐옙 Advice占쏙옙 타占쏙옙占쏙옙 占싯아놂옙占싹댐옙. 
		logger.info("2:" + jp.getKind());

		// 占쏙옙占쏙옙占싹댐옙 占쏙옙占� 占쏙옙체占쏙옙 占쌨소드에 占쏙옙占쏙옙 占쏙옙占쏙옙占쏙옙 占싯아놂옙 占쏙옙 占쏙옙占쏙옙爛求占�. 
		logger.info("3:" + jp.getSignature().getName());

		// target 占쏙옙체占쏙옙 占싯아놂옙 占쏙옙 占쏙옙占쏙옙爛求占�. 
		logger.info("4:" + jp.getTarget().toString());

		// Advice占쏙옙 占쏙옙占싹댐옙 占쏙옙체占쏙옙 占싯아놂옙 占쏙옙 占쏙옙占쏙옙爛求占�. 
		logger.info("5:" + jp.getThis().toString());

	}
	
	@After("execution(* com.isekaiMkt.*.service.*.*(..)) or "
			+ "execution(* com.isekaiMkt.*.*.dao.*.*(..))")
	public void after(JoinPoint jp) { 
		logger.info("-------------------------------------");
		logger.info("-------------------------------------");

		// 占쏙옙占쌨되댐옙 占쏙옙占� 占식띰옙占쏙옙孤占쏙옙占� Object占쏙옙 占썼열占쏙옙 占쏙옙占쏙옙占심니댐옙. 
		logger.info("1:" + Arrays.toString(jp.getArgs()));

		// 占쌔댐옙 Advice占쏙옙 타占쏙옙占쏙옙 占싯아놂옙占싹댐옙. 
		logger.info("2:" + jp.getKind());

		// 占쏙옙占쏙옙占싹댐옙 占쏙옙占� 占쏙옙체占쏙옙 占쌨소드에 占쏙옙占쏙옙 占쏙옙占쏙옙占쏙옙 占싯아놂옙 占쏙옙 占쏙옙占쏙옙爛求占�.
		logger.info("3:" + jp.getSignature().getName());

		// target 占쏙옙체占쏙옙 占싯아놂옙 占쏙옙 占쏙옙占쏙옙爛求占�. 
		logger.info("4:" + jp.getTarget().toString());

		// Advice占쏙옙 占쏙옙占싹댐옙 占쏙옙체占쏙옙 占싯아놂옙 占쏙옙 占쏙옙占쏙옙爛求占� 
		logger.info("5:" + jp.getThis().toString());
	
	}


	// target 占쌨소듸옙占쏙옙 占쏙옙占쏙옙 占시곤옙占쏙옙 占쏙옙占쏙옙占쌌니댐옙.
	@Around("execution(* com.isekaiMkt.*.service.*.*(..)) or "
			+ "execution(* com.isekaiMkt.*.dao.*.*(..))")
	public Object timeLog(ProceedingJoinPoint pjp) throws Throwable {
		long startTime = System.currentTimeMillis();
		logger.info(Arrays.toString(pjp.getArgs()));

		// 占쏙옙占쏙옙 타占쏙옙占쏙옙 占쏙옙占쏙옙占싹댐옙 占싸븝옙占싱댐옙. 占쏙옙 占싸븝옙占쏙옙 占쏙옙占쏙옙占쏙옙 advice占쏙옙 占쏙옙占쏙옙占� 占쌨소드가 占쏙옙占쏙옙占쏙옙占쏙옙占십쏙옙占싹댐옙.
		Object result = pjp.proceed(); // proceed占쏙옙 Exception 占쏙옙占쏙옙 占쏙옙占쏙옙 Throwable占쏙옙 처占쏙옙占쌔억옙 占쌌니댐옙.

		long endTime = System.currentTimeMillis();
		// target 占쌨소듸옙占쏙옙 占쏙옙占쏙옙 占시곤옙占쏙옙 占쏙옙占쏙옙磯占�.
		logger.info(pjp.getSignature().getName() + " : " + (endTime - startTime)); 
		logger.info("==============================");

		// Around占쏙옙 占쏙옙占쏙옙占� 占쏙옙占� 占쌥듸옙占� Object占쏙옙 占쏙옙占쏙옙占쌔억옙 占쌌니댐옙.
		return result;
	}

}
